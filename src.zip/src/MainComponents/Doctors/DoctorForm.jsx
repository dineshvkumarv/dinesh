import React, { useState, useEffect } from "react";
import { Form, Row, Col, Button, Container, FormControl, CloseButton } from "react-bootstrap";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";

function DoctorForm() {
  //const location = useLocation();  // To get passed state
  const navigate = useNavigate();

  
  const location = useLocation();
  const hospitalData = location.state?.doctor || {};  


  const [doctorData, setDoctorData] = useState({
    name: hospitalData.name || "",
    committedCases: hospitalData.committedCases || "",
    remarks: hospitalData.remarks || "",
    hospitalId: hospitalData.hospitalId || "",
  });

  const [principles, setPrinciples] = useState([]);





  // Fetching the list of hospitals (principles)
  useEffect(() => {
    axios
     // .get("http://77.37.45.2:1000/api/v1/hospitalregistration/fetchallhospitalregistrations")
      .get(" http://77.37.45.2:8091/api/v1/doctorregistration/fetchalldoctorregistrations")
      .then((response) => setPrinciples(response.data.reverse()))
      .catch((error) => console.error("Error fetching hospitals:", error));

    // If there's an existing doctor data, populate the form
    if (location.state && location.state.doctor) {
      const doctor = location.state.doctor;
      setDoctorData({
        name: doctor.name || "",
        committedCases: doctor.committedCases || "",
        remarks: doctor.remarks || "",
        hospitalId: doctor.hospitalRegistrations[0]?.id || "",
      });
    }
  }, [location.state]);

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setDoctorData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Handle form submission (for both add and update)
  const handleSubmit = (e) => {
    e.preventDefault();
console.log(doctorData);

    const apiEndpoint = location.state ? 
      `http://77.37.45.2:8091/api/v1/doctorregistration/updatedoctorregistration/${location.state.doctor.id}` :
      "http://77.37.45.2:1000/api/v1/doctor/saveDoctor";

    const method = location.state ? "PUT" : "POST";  // Choose method based on state presence

    axios({
      method,
      url: apiEndpoint,
      data: {
        name: doctorData.name,
        committedCases: doctorData.committedCases,
        remarks: doctorData.remarks,
        hospitalRegistrations: [
          {
            id: doctorData.hospitalId,
          },
        ],
      },
    })
      .then((response) => {
        console.log("Doctor data submitted successfully:", response.data);
        navigate("/doctors");  // Navigate back to the list page after submit
      })
      .catch((error) => {
        console.error("Error submitting doctor data:", error);
      });
  };

  return (
    <div>
      <Container className="Product-Container">
        <div className="addProductHeaderClass">
          <h3 className="addnewProductHeader">
            {location.state ? "Edit Doctor" : "Add Doctor"}
          </h3>

          <div id="closeModalBtnPrin">
            <CloseButton onClick={() => navigate("/doctors")} />
          </div>
        </div>
        <hr />

        <Form onSubmit={handleSubmit}>
          <Row className="mb">
            <Form.Group as={Col}>
              <Form.Label>Doctor Name:</Form.Label>
              <FormControl
                type="text"
                name="name"
                value={doctorData.name}
                onChange={handleInputChange}
                placeholder="Ex: Dr. Sailesh"
              />
            </Form.Group>
          </Row>

          <Row className="mb-3">
            <Form.Group as={Col}>
              <Form.Label>Select Hospital:</Form.Label>
              <Form.Select
                name="hospitalId"
                value={doctorData.hospitalId}
                onChange={handleInputChange}
              >
                <option>Select...</option>
                {principles.map((principle) => (
                  <option key={principle.id} value={principle.id}>
                    {principle.hospitalRegistrations[0].name}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>
          </Row>

          <Row className="mb">
            <Form.Group as={Col}>
              <Form.Label>Committed Cases:</Form.Label>
              <FormControl
                type="text"
                name="committedCases"
                value={doctorData.committedCases}
                onChange={handleInputChange}
                placeholder="Ex: Committed Cases by Doctor"
              />
            </Form.Group>
          </Row>

          <Row className="mb">
            <Form.Group as={Col}>
              <Form.Label>Remarks:</Form.Label>
              <FormControl
                type="text"
                name="remarks"
                value={doctorData.remarks}
                onChange={handleInputChange}
                placeholder="Ex: Remarks"
              />
            </Form.Group>
          </Row>

          <div id="ProductFormSubmitBtnDiv">
            <Button variant="primary" id="ProductFormSubmitBtn" type="submit">
              {location.state ? "Update" : "Submit"}
            </Button>
          </div>
        </Form>
      </Container>
    </div>
  );
}

export default DoctorForm;
