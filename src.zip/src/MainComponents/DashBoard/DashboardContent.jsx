import React from 'react'

function DashboardContent() {
  return (
    <div>
        <h1> I am in Main Dashboard  </h1>
    </div>
  )
}

export default DashboardContent


