import React, { useEffect, useState } from "react"; // Import React and useState
import { Link, Route, Routes } from "react-router-dom"; // Import Link for navigation
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS
import "bootstrap-icons/font/bootstrap-icons.css"; // Import Bootstrap Icons
import "./Dashboard.css"; // Import custom CSS

import DashboardIcon from "@mui/icons-material/Dashboard";
import LocalHospitalIcon from "@mui/icons-material/LocalHospital";
import CategoryIcon from "@mui/icons-material/Category";
import BusinessCenterIcon from "@mui/icons-material/BusinessCenter";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import PeopleAltIcon from "@mui/icons-material/PeopleAlt";
import PersonIcon from "@mui/icons-material/Person";
import BusinessIcon from "@mui/icons-material/Business";
import AssignmentIcon from "@mui/icons-material/Assignment";

import Departments from "../Departments/Departments";
import HospitalTable from "../Hospitals/HospitalTable/HospitalTable";
import Categories from "../Categorys/Categories";
import Principles from "../Principles/Principles";
import { EditForm } from "../Hospitals/HospitalForm/HospitalEditForm";
import HospitalRegistrationForm from "../Hospitals/HospitalForm/HospitalRegistrationForm";
import Products from "../Products/Products";
import SalesEmployee from "../Sales Employee/SalesEmployee";
import DashboardContent from "./DashboardContent";
 
import DoctorsTable from "../Doctors/DoctorsTable";
 
import CaseTable from "../CaseCreation/CaseTable";
import CaseForm from "../CaseCreation/CaseForm";
import DoctorForm from "../Doctors/DoctorForm";
 
// import DepartmentsForm from "../Departments/DepartmentsForm";
import PrincipleForm from "../Principles/PrincipleForm";
import SalesEmployeeForm from "../Sales Employee/SalesEmployeeForm";
import ProductForm from "../Products/ProductForm";
// import HospitalTable from "../Hospitals/HospitalTable/HospitalTable";

const Dashboard = () => {
  const [isSidebarVisible, setSidebarVisible] = useState(false); // State for sidebar visibility
  const [isMouseOverSidebar, setIsMouseOverSidebar] = useState(false);


  const handleMouseEnter = () => setIsMouseOverSidebar(true);

  const handleMouseLeave = () => setIsMouseOverSidebar(false);


  useEffect(() => {
    if (!isMouseOverSidebar) {
      setSidebarVisible(false);
    }
  }, [isMouseOverSidebar]);


  // Toggle sidebar visibility
  const toggleSidebar = () => {
    setSidebarVisible(!isSidebarVisible);
  };

  return (
    <div className="d-flex flex-column">
      {/* Navigation bar */}

      <nav
        className={`navbar navbar-expand-lg navbar-dark bg-primary full-width-navbar ${
          isSidebarVisible ? "shifted" : ""
        }`}
      >
        <div className="container-fluid">
          {/* Sidebar toggle button */}

          {!isSidebarVisible && (
            <span
              className="navbar-toggler-icon me-2"
              role="button"
              aria-expanded={isSidebarVisible}
              onClick={toggleSidebar}
              aria-label="Toggle sidebar"
            ></span>
          )}

          {/* Brand name */}
          <a className="navbar-brand me-auto" href="#">
            Matryx Medisys
            <span className="d-block fs-6 text-warning">
              Medical Excellence
            </span>
          </a>

          {/* Search form */}
          <form className="d-flex" role="search">
            <input
              className="form-control me-2"
              type="search"
              placeholder="Search..."
              aria-label="Search"
            />
          </form>

          {/* User action icons */}
          <div className="d-flex align-items-center ms-3">
            <Link
              to="mailto:aravindgowda43@gmail.com"
              className="text-white"
              aria-label="Email"
            >
              <i className="bi bi-envelope fs-4 mx-2"></i>
            </Link>
            <Link to="#" className="text-white" aria-label="Notifications">
              <i className="bi bi-bell fs-4 mx-2"></i>
            </Link>
            <Link to="#" className="text-white" aria-label="Profile">
              <i className="bi bi-person fs-4 mx-2"></i>
            </Link>
          </div>
        </div>
      </nav>

      <div className="d-flex flex-grow-1">
        {/* Sidebar */}
        <div
          className={`sidebar ${isSidebarVisible ? "visible" : "hidden"}`}
          id="sidebar"
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          <button
            className="collapse-btn"
            id="collapse-btn"
            aria-label="Collapse Sidebar"
            onClick={toggleSidebar}
          >
            <i className="bi bi-chevron-left"></i>
          </button>


          <br />
          <br />
          <br />


          <ul className="nav flex-column">
            {/* Navigation links */}
            <li className="nav-item">
              <Link className="nav-link text-dark" activeClassName="active-link" to="/dashboard">
                <DashboardIcon />
                <span id="spaceBetweenIconHeading"> Dashboard </span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-dark" activeClassName="active-link" to="/case-table  ">
                <AssignmentIcon />
                <span id="spaceBetweenIconHeading"> Case creation </span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-dark" to="/hospitals">
                <LocalHospitalIcon />
                <span id="spaceBetweenIconHeading"> Hospitals </span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-dark" to="/doctors">
                <PeopleAltIcon />
                <span id="spaceBetweenIconHeading"> Doctors</span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-dark" to="/categories">
                <CategoryIcon />
                <span id="spaceBetweenIconHeading"> Categorys </span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-dark" to="/principles">
                <BusinessCenterIcon />
                <span id="spaceBetweenIconHeading"> Principles</span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-dark" to="/products">
                <ShoppingCartIcon />
                <span id="spaceBetweenIconHeading"> Products </span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-dark" to="/departments">
                <BusinessIcon />
                <span id="spaceBetweenIconHeading"> Departments </span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-dark" to="/sales-employee">
                <PersonIcon />
                <span id="spaceBetweenIconHeading"> Sales Employee </span>
              </Link>
            </li>
          </ul>
        </div>

        {/* Main content area */}
        <main
          className={`main-content flex-grow-1 p-4 ${
            isSidebarVisible ? "" : "full-width"
          }`}
          id="main-content"
        >
          <Routes>
            {/* Define routes for the application */}

            {/* Default route */}
            {/* <Route path= "/" element={<Dashboard11 />} /> */}
            <Route path="/" element={<DashboardContent />} />

            {/* wrong path */}
            {/* <Route path="*" element={<WrongPath />} /> */}
            {/* <Route path="*" element={<Products />} /> */}

            {/* Route for DashBoard */}
            <Route path="/dashboard" element={<DashboardContent />} />

            {/* Route for CaseCreation */}
            <Route path="/case-table" element={<CaseTable />} />
            <Route path="/case-form"  element={<CaseForm/>}  />

            {/* Route for Hospitals */}
            <Route path="/hospitals" element={<HospitalTable />} />
            <Route path="/hospitals/addForm" element={<HospitalRegistrationForm />} />
            <Route path="/hospitals/editForm" element={<EditForm />} />

            {/* Route for Doctors */}
            <Route path="/doctors" element={<DoctorsTable />} />
            <Route path="/doctors-form" element={<DoctorForm />} />

            {/* Route for Categorys */}
            <Route path="/categories" element={<Categories />} />

            {/* Route for  Principles */}
            <Route path="/principles" element={<Principles />} />
            <Route path="/principle-form" element={<PrincipleForm />} />
             
            {/* Route for  Products */}
            <Route path="/products" element={<Products />} />
            <Route path="/products-form" element={<ProductForm />} />
            

            {/* Route for  Departments */}
            <Route path="/departments" element={<Departments />} />
            {/* <Route path="/department-form" element={<DepartmentsForm />} /> */}

            {/* Route for  Sales Employee */}
            <Route path="/sales-employee" element={<SalesEmployee />} />
            <Route path="/sales-employee-form" element={<SalesEmployeeForm />} />



          </Routes>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
