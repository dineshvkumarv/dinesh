import React from 'react'

function WrongPath() {
  return (
    <div> 
        <h2>You have Entered Wrong path </h2>
        <h3>Please Enter Correct Path and Try Again</h3>
    </div>
  )
}

export default WrongPath