import React, { useEffect, useState } from "react";
import {
  Form,
  Row,
  Col,
  Button,
  Container,
  FormControl,
  CloseButton,
} from "react-bootstrap";

import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";

function  SalesEmployeeForm() {
  const [principles, setPrinciples] = useState([]);
  const [departmentName, setDepartmentName] = useState(""); // For department name
  const [employeeName, setEmployeeName] = useState(""); // For employee name
  const [employeePhone, setEmployeePhone] = useState(""); // For employee phone
  const [employeeTargets, setEmployeeTargets] = useState(""); // For employee targets
  const [selectedDepartment, setSelectedDepartment] = useState(null); // For selected department

  const navigate = useNavigate(); // Use for navigation
  const { state } = useLocation();
  const editingEmployee = state?.employee || null; // Check if we are in edit mode

 
  

  useEffect(() => {
    if (editingEmployee) {
      console.log(editingEmployee);
      setEmployeeName(editingEmployee.name || "");
      setEmployeePhone(editingEmployee.phonenumber || "");
      setEmployeeTargets(editingEmployee.targets || "");
      const department = principles.find(
        (dept) => dept.id === editingEmployee.department?.id // Use optional chaining
      );
      setSelectedDepartment(department || null);
    }
  }, [editingEmployee, principles]);

  useEffect(() => {
    axios
      .get("http://77.37.45.2:8091/api/v1/department/fetchalldepartments")
      .then((response) => setPrinciples(response.data)) // Set the principles array (list of departments)
      .catch((error) => console.error("Error fetching departments:", error));
  }, []);

  const handleAddDepartment = () => {
    if (!departmentName) {
      alert("Please enter a department name");
      return;
    }

    const departmentData = {
      name: departmentName,
      description: "Test " + departmentName, // Just a placeholder for description
    };

    axios
      .post(
        "http://77.37.45.2:8091/api/v1/department/savedepartment",
        departmentData
      )
      .then((response) => {
        console.log("Department added successfully:", response.data);
        setDepartmentName(""); // Clear department name field after successful submission
      })
      .catch((error) => {
        console.error("Error adding department:", error);
      });
  };

  const handleSubmit = () => {
    if (!employeeName || !employeePhone || !selectedDepartment) {
      alert("Please fill in all required fields");
      return;
    }

    const employeeData = {
      name: employeeName,
      phonenumber: employeePhone,
      targets: employeeTargets,
      departmentId: selectedDepartment.id,
    };

    if (editingEmployee) {
      // Update existing employee
      axios
        .put(
          `http://77.37.45.2:8091/api/v1/internalemployee/updateinternalemployee/${editingEmployee.id}`,
          employeeData
        )
        .then((response) => {
          console.log("Employee updated successfully:", response.data);
          navigate("/sales-employee");
        })
        .catch((error) => console.error("Error updating employee:", error));
    } else {
      // Add new employee
      axios
        .post(
          "http://77.37.45.2:8091/api/v1/internalemployee/saveinternalemployee",
          employeeData
        )
        .then((response) => {
          console.log("Employee added successfully:", response.data);
          navigate("/sales-employee");
        })
        .catch((error) => console.error("Error adding employee:", error));
    }
  };

  return (
    <div>
      <Container className="Product-Container">
        <div className="addProductHeaderClass">
          <h3 className="addnewProductHeader">
            {editingEmployee ? "Edit Employee" : "New Employee"}
          </h3>

          <div id="closeModalBtnPrin">
            <CloseButton onClick={() => navigate("/sales-employee")} />
          </div>
        </div>
        <hr />

        <Form>

    

          <Row className="mb-3">
            <Form.Group as={Col}>
              <Form.Label>Employee Name: </Form.Label>
              <FormControl
                placeholder="Ex: Mr. Ramesh"
                value={employeeName}
                onChange={(e) => setEmployeeName(e.target.value)}
              />
            </Form.Group>

            <Form.Group as={Col}>
              <Form.Label>Employee Phone: </Form.Label>
              <FormControl
                type="number"
                placeholder="+91 XXXXXXXXXX"
                value={employeePhone}
                onChange={(e) => setEmployeePhone(e.target.value)}
              />
            </Form.Group>
          </Row>

          <Row className="mb-3">
            <Form.Group as={Col}>
              <Form.Label>Department:</Form.Label>
              <Form.Select
                value={selectedDepartment ? selectedDepartment.id : ""}
                onChange={(e) => {
                  const selected = principles.find(
                    (dept) => dept.id === parseInt(e.target.value)
                  );
                  setSelectedDepartment(selected);
                }}
              >
                <option>Select a Department</option>
                {principles.map((principle) => (
                  <option key={principle.id} value={principle.id}>
                    {principle.name}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>
          </Row>

          <Row className="mb-3">
            <Form.Group as={Col}>
              <Form.Label>Targets: </Form.Label>
              <FormControl
                placeholder="Ex: 1"
                value={employeeTargets}
                onChange={(e) => setEmployeeTargets(e.target.value)}
              />
            </Form.Group>
          </Row>

          <div id="ProductFormSubmitBtnDiv">
            <Button
              variant="primary"
              id="ProductFormSubmitBtn"
              onClick={handleSubmit}
            >
              {editingEmployee ? "Update Employee" : "Add Employee"}
            </Button>
          </div>
        </Form>
      </Container>
    </div>
  );
}

export default SalesEmployeeForm;
