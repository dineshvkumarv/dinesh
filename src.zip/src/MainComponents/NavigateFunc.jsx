import { useNavigate } from "react-router-dom";

export default function NavigateFunc({ path }) {
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate(path);
  };

  return handleNavigate;
}


  