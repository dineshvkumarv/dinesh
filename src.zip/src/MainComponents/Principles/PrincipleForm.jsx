import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import "./PrincipleForm.css"
import CloseButton from 'react-bootstrap/CloseButton';
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import NavigateFunc from "../NavigateFunc";
import { Button } from "react-bootstrap";
import axios from "axios";


function PrincipleForm() {

  const location = useLocation();
  const principleId = location.state?.principleId;  // Retrieve principleId for editing
  

  const [principleData, setPrincipleData] = useState({
    name: "",
    description: "",
  });

  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPrincipleData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };


  useEffect(() => {
    if (principleId) {
      axios
        .get(`http://77.37.45.2:8091/api/v1/principle/fetchprinciple/${principleId}`)
        .then((response) => {
          setPrincipleData(response.data);  // Set form fields with the fetched data
        })
        .catch((error) => {
          console.error("Error fetching principle data:", error);
        });
    }
  }, [principleId]);
  
  
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(principleData);
    
    const url = principleId
      ? `http://77.37.45.2:8091/api/v1/principle/updatecategory/${principleId}`
      : "http://77.37.45.2:8091/api/v1/principle/saveprinciple";  // Use PUT for editing
    const method = principleId ? "PUT" : "POST";  // POST for add, PUT for update
  
    axios({
      method,
      url,
      data: principleData,
    })
      .then((response) => {
        console.log("Data submitted successfully:", response.data);
        Navigate("/principles");  // Redirect after submit
      })
      .catch((error) => {
        console.error("Error submitting data:", error);
      });
  };
  


  return (
    <div
       
    >
      <div id="principleSubDiv">


      <div id="closeModalBtnPrin">   <CloseButton onClick={ NavigateFunc({ path: "/principles" })}  />    </div>
      




        <div className="containerPrincipalForm">
          <Form.Group className="mb-3" controlId="formGridAddress1">
            <Form.Label> Supplier/Principle: </Form.Label>
            <Form.Control
              type="text"
              placeholder="Please Enter Supplier"
              name="name"
              value={principleData.name}
              onChange={handleInputChange}
            />
          </Form.Group>
        </div>

        <Button variant="primary" onClick={handleSubmit}> 

        {principleId ? "Update" : "Add"}
        </Button>
      </div>
    </div>
  );
}

export default PrincipleForm;

