 
// This function validates the hospital form data and sets errors if any fields are invalid.
export function validateHospitalForm(formData, setErrors) {
    
    let valid = true; // Initialize the validity flag to true
    const newErrors = {}; // Object to store new error messages

    // Clear previous error messages before setting new ones
    setErrors({});

    // Destructure the formData object for easier field access
    const { name, email, phone, location, address, pincode, stateId, cityId } = formData;

    // Validate 'name' field: it should not be empty
    if (!name) {
        newErrors.name = 'Hospital Name is required.';
        valid = false; // Mark form as invalid if this check fails
    }

    // Validate 'email' field: it should be non-empty and in a proper email format
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
        newErrors.email = 'Valid Email is required.';
        valid = false;
    }

    // Validate 'phone' field: it should be exactly 10 digits
    if (!phone || !/^\d{10}$/.test(phone)) {
        newErrors.phone = 'Phone is required.';
        valid = false;
    }

    // Validate 'address' field: it should not be empty
    if (!address) {
        newErrors.address = 'Address is required.';
        valid = false;
    }

    // Validate 'location' field: it should not be empty
    if (!location) {
        newErrors.location = 'Location is required.';
        valid = false;
    }

    // Validate 'pincode' field: it should be a valid 6-digit number
    if (!pincode || !/^\d{6}$/.test(pincode)) {
        newErrors.pincode = 'Valid Pincode is required.';
        valid = false;
    }

    // Validate 'stateId' field: it should not be empty
    if (!stateId) {
        newErrors.stateId = 'Please select a state.';
        valid = false;
    }

    // Validate 'cityId' field: it should not be empty
    if (!cityId) {
        newErrors.cityId = 'Please select a city.';
        valid = false;
    }

    // Set the new error messages using setErrors function
    setErrors(newErrors);
    
    // Return the overall validity status of the form
    return valid;
}
