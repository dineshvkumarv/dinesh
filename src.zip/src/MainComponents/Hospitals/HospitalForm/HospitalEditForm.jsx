import React, { useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import axios from "axios";
import { useFormValidations } from "./useFormValidations";
import "./EditForm.css";
import { useNavigate } from "react-router-dom";
import {HospitalTable, fetchHospitals} from "../HospitalTable/HospitalTable";

export const EditForm = ({ hospital, onClose, refreshHospitals }) => {
  const [showEditModal, setShowEditModal] = useState(true);
  const { errors, validateField, validateForm } = useFormValidations();
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedState, setSelectedState] = useState(hospital.state?.id || "");
  const [selectedCity, setSelectedCity] = useState(hospital.city?.id || "");

  const [formData, setFormData] = useState({
    name: hospital.name || "",
    email: hospital.email || "",
    phone: hospital.phone || "",
    address: hospital.address || "",
    location: hospital.location || "",
    pincode: hospital.pincode || "",
    stateId: hospital.state?.id || "",
    cityId: hospital.city?.id || "",
  });

  useEffect(() => {
    axios
      .get("http://77.37.45.2:1000/api/v1/state/fetchallstate")
      .then((response) => setStates(response.data))
      .catch((error) => console.error("Error fetching states:", error));
  }, []);

  useEffect(() => {
    if (selectedState) {
      fetchCities(selectedState);
    }
  }, [selectedState]);

  const fetchCities = (stateId) => {
    axios
      .get("http://77.37.45.2:1000/api/v1/city/fetchallcity")
      .then((response) => {
        const filteredCities = response.data.filter(
          (city) => city.stateValueId === Number(stateId)
        );
        setCities(filteredCities);
      })
      .catch((error) => console.error("Error fetching cities:", error));
  };

  const handleStateChange = (e) => {
    const stateId = e.target.value;
    setSelectedState(stateId);
    setFormData((prev) => ({ ...prev, stateId, cityId: "" }));
    setCities([]);
    fetchCities(stateId);
    validateField("stateId", stateId);
  };

  const handleCityChange = (e) => {
    const cityId = e.target.value;
    setSelectedCity(cityId);
    setFormData((prev) => ({ ...prev, cityId }));
    validateField("cityId", cityId);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    validateField(name, value);
  };
  const navigate = useNavigate();


  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm(formData)) return;

    try {
      await axios.put(
        `http://77.37.45.2:1000/api/v1/hospitalregistration/updatehospitalregistration/${hospital.id}`,
        formData
      );
      alert(`${formData.name} Updated Successfully`);

      refreshHospitals(); // Refresh data in HospitalTable
      onClose(); // Close the modal
      navigate("/hospitals"); // Optional: navigate back if needed
    } catch (error) {
      console.error("Error updating data:", error);
    }
  };

  const handleCloseEditForm = () => {
    setShowEditModal(false);
    onClose();
  };

  return (
    <Modal
      show={showEditModal}
      onHide={handleCloseEditForm}
      id="modalEditForm"
      centered
      backdrop={true} // Ensure backdrop is active
      dialogClassName="customModalDialog"
    
    >
      <Modal.Header closeButton>
        <Modal.Title className="custom-modal-title">Edit Hospital</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="card-body">
          <div className="row mb-3">
            <label className="form-label">Hospital Name</label>
            <input
              type="text"
              name="name"
              className={`form-control ${errors.name ? "is-invalid" : ""}`}
              value={formData.name}
              onChange={handleChange}
              placeholder="Ex: Apollo Hospital"
            />
            {errors.name && (
              <div className="invalid-feedback">{errors.name}</div>
            )}
          </div>

          <div className="row mb-3">
            <div className="col">
              <label className="form-label">Email</label>
              <input
                type="email"
                name="email"
                className={`form-control ${errors.email ? "is-invalid" : ""}`}
                value={formData.email}
                onChange={handleChange}
                placeholder="Ex: apollohospital@gmail.com"
              />
              {errors.email && (
                <div className="invalid-feedback">{errors.email}</div>
              )}
            </div>

            <div className="col">
              <label className="form-label">Phone</label>
              <input
                type="tel"
                name="phone"
                className={`form-control ${errors.phone ? "is-invalid" : ""}`}
                value={formData.phone}
                onChange={handleChange}
                placeholder="Ex: +91 XXXXXXXXXX or 022-XXXXXXX"
              />
              {errors.phone && (
                <div className="invalid-feedback">{errors.phone}</div>
              )}
            </div>
          </div>

                {/* <HospitalTable/> */}

          <div className="mb-3">
            <label className="form-label">Address</label>
            <input
              type="text"
              name="address"
              className={`form-control ${errors.address ? "is-invalid" : ""}`}
              value={formData.address}
              onChange={handleChange}
              placeholder="Ex: 154, Bannerghatta Rd, Krishnaraju Layout, Amalodhbavi Nagar"
            />
            {errors.address && (
              <div className="invalid-feedback">{errors.address}</div>
            )}
          </div>

          <div className="mb-3">
            <label className="form-label">Location</label>
            <input
              type="text"
              name="location"
              className={`form-control ${errors.location ? "is-invalid" : ""}`} // Apply error styling
              value={formData.location}
              placeholder="Ex: Bannerghatta"
              onChange={handleChange} // Handle input change
            />
            {errors.location && (
              <div className="invalid-feedback">{errors.location}</div> // Show error message
            )}
          </div>

          <div className="row">
            {/* State */}
            <div className="col-md-4 mb-3">
              <label className="form-label">Select State</label>
              <select
                name="stateId"
                className={`form-select ${errors.stateId ? "is-invalid" : ""}`} // Apply error styling
                value={selectedState}
                onChange={handleStateChange} // Handle state change
              >
                <option value="">Select a state</option>
                {states.map((state) => (
                  <option key={state.id} value={state.id}>
                    {state.name}
                  </option>
                ))}
              </select>
              {errors.stateId && (
                <div className="invalid-feedback">{errors.stateId}</div> // Show error message
              )}
            </div>

            {/* City */}
            <div className="col-md-4 mb-3">
              <label className="form-label">Select City</label>
              <select
                name="cityId"
                className={`form-select ${errors.cityId ? "is-invalid" : ""}`} // Apply error styling
                value={selectedCity}
                onChange={handleCityChange} // Handle city change
                disabled={!selectedState} // Disable if no state is selected
              >
                <option value="">Select a city</option>
                {cities.map((city) => (
                  <option key={city.id} value={city.id}>
                    {city.name}
                  </option>
                ))}
              </select>
              {errors.cityId && (
                <div className="invalid-feedback">{errors.cityId}</div> // Show error message
              )}
            </div>

            {/* Pincode */}
            <div className="col-md-4 mb-3">
              <label className="form-label">Pincode</label>
              <input
                type="text"
                name="pincode"
                className={`form-control ${errors.pincode ? "is-invalid" : ""}`} // Apply error styling
                value={formData.pincode}
                placeholder="Ex: 560055"
                onChange={handleChange} // Handle input change
              />
              {errors.pincode && (
                <div className="invalid-feedback">{errors.pincode}</div> // Show error message
              )}
            </div>
          </div>

          {/* <button
            type="submit"
            className="btn btn-primary"
            id="submitId"
            disabled={Object.values(errors).some((error) => error)}
          >
            Update
          </button> */}
        </div>
      </Modal.Body>

      <Modal.Footer className="justify-content-center">
        <button
          type="submit"
          form="hospitalForm"
          className="btn btn-primary"
          disabled={Object.values(errors).some((error) => error)}
          onClick={handleSubmit}
        >
          Update
        </button>
      </Modal.Footer>
    </Modal>
  );
};
