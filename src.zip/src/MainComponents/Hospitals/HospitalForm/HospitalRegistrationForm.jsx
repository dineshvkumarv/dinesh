 import React, { useState, useEffect } from "react";
import "./HospitalRegistrationForm.css";
import axios from "axios";
import { useFormValidations } from "./useFormValidations"; // Import the custom hook
import { useNavigate } from "react-router-dom";

const HospitalRegistrationForm = () => {
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedState, setSelectedState] = useState("");
  const [selectedCity, setSelectedCity] = useState("");

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    location: "",
    address: "",
    pincode: "",
    stateId: "",
    cityId: "",
  });

  // const { errors, validateForm } = useFormValidations(); // Get errors and validateForm from the hook

  const [errors, setErrors] = useState({
    name: "",
    email: "",
    phone: "",
    location: "",
    address: "",
    pincode: "",
    stateId: "",
    cityId: "",
  });

  // Fetch states from API
  useEffect(() => {
    axios
      .get("http://77.37.45.2:1000/api/v1/state/fetchallstate")
      .then((response) => {
        setStates(response.data);
      })
      .catch((error) => {
        console.error("Error fetching states:", error);
      });
  }, []);

  // Fetch cities based on selected state
  const fetchCities = (selectedStateId) => {
    axios
      .get("http://77.37.45.2:1000/api/v1/city/fetchallcity")
      .then((response) => {
        const filteredCities = response.data.filter(
          (city) => city.stateValueId === Number(selectedStateId)
        );
        setCities(filteredCities);
      })
      .catch((error) => {
        console.error("Error fetching cities:", error);
      });
  };

  // Handle form input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));

    // Trigger validation for this specific field
    validateField(name, value);
  };

  const handleStateChange = (e) => {
    const selectedStateId = e.target.value;
    setSelectedState(selectedStateId);
    setSelectedCity("");
    setFormData((prevData) => ({
      ...prevData,
      stateId: selectedStateId,
      cityId: "",
    }));
    setCities([]);
    fetchCities(selectedStateId);

    // Trigger validation for state change
    validateField("stateId", selectedStateId);
  };

  const handleCityChange = (e) => {
    const selectedCityId = e.target.value;
    setSelectedCity(selectedCityId);
    setFormData((prevData) => ({ ...prevData, cityId: selectedCityId }));

    // Trigger validation for city change
    validateField("cityId", selectedCityId);
  };

  const validateField = (fieldName, fieldValue) => {
    const updatedErrors = { ...errors };

    switch (fieldName) {
      case "name":
        updatedErrors.name = fieldValue.trim() === "" ? "Name is required" : "";
        break;
      case "email":
        updatedErrors.email = !/\S+@\S+\.\S+/.test(fieldValue)
          ? "Valid email is required"
          : "";
        break;
      case "phone":
        updatedErrors.phone = !/^\+?\d{10,15}$/.test(fieldValue)
          ? "Phone number is invalid"
          : "";
        break;
      case "location":
        updatedErrors.location =
          fieldValue.trim() === "" ? "Location is required" : "";
        break;
      case "address":
        updatedErrors.address =
          fieldValue.trim() === "" ? "Address is required" : "";
        break;
      case "pincode":
        updatedErrors.pincode = !/^\d{6}$/.test(fieldValue)
          ? "Valid pincode is required"
          : "";
        break;
      case "stateId":
        updatedErrors.stateId = fieldValue === "" ? "State is required" : "";
        break;
      case "cityId":
        updatedErrors.cityId = fieldValue === "" ? "City is required" : "";
        break;
      default:
        break;
    }

    // Update the errors state with the new errors
    setErrors(updatedErrors);
  };

  const navigate = useNavigate();

  const handleNavigate = () => {
    // Navigate to the "/about" route
    navigate("/hospitals");
  };

  const handleClose = () => {
    handleNavigate();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate the entire form before submitting
    const isValid = validateForm(formData);
    if (!isValid) return; // Stop if form is invalid

    try {
      const response = await axios.post(
        "http://77.37.45.2:1000/api/v1/hospitalregistration/savehospitalregistration",
        formData
      );
      console.log("Data posted successfully:", response.data);
      alert(`${response.data.name} Added Successfully`);
      handleNavigate();

      // Optionally reset the form after successful submission
      resetForm();
    } catch (error) {
      console.error("Error posting data:", error);
    }
  };

  // Validate the entire form
  const validateForm = (formData) => {
    let valid = true;
    const newErrors = { ...errors };

    Object.keys(formData).forEach((field) => {
      if (formData[field] === "" || errors[field] !== "") {
        newErrors[field] = `${field} is required or invalid`;
        valid = false;
      }
    });

    setErrors(newErrors);
    return valid;
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      phone: "",
      location: "",
      address: "",
      pincode: "",
      stateId: "",
      cityId: "",
    });
    setSelectedState("");
    setSelectedCity("");
    setCities([]);
  };

  return (
    <div
      id="form-container"
      style={{
        display: "flex",
        alignItems: "center",
        width: "50%",
        marginLeft: "25%",
      }}
    >
      <div className="container mt-2">
        <div className="card">
          <div className="card-header d-flex justify-content-between align-items-center">
            <h5 style={{ marginLeft: "35%", fontSize: "30px" }}>
              Add Hospital
            </h5>

            <button
              type="button"
              id="closeModalBtn"
              className="btn-close"
              aria-label="Close"
              onClick={handleClose}
            ></button>
          </div>

          <div className="card-body">
            <form onSubmit={handleSubmit} id="hospitalForm">
              {/* Hospital Name */}
              <div className="row mb-3">
                <label htmlFor="hospitalName" className="form-label">
                  Hospital Name
                </label>
                <input
                  type="text"
                  name="name"
                  className={`form-control ${errors.name ? "is-invalid" : ""}`}
                  id="hospitalName"
                  placeholder="Ex: Apollo Hospital"
                  value={formData.name}
                  onChange={handleChange}
                />
                {errors.name && (
                  <div className="invalid-feedback">{errors.name}</div>
                )}
              </div>

              <div className="row mb-3">
                {/* Email */}
                <div className="col">
                  <label htmlFor="hospitalEmail" className="form-label">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    className={`form-control ${
                      errors.email ? "is-invalid" : ""
                    }`}
                    id="hospitalEmail"
                    placeholder="Ex: apollohospital@gmail.com"
                    value={formData.email}
                    onChange={handleChange}
                  />
                  {errors.email && (
                    <div className="invalid-feedback">{errors.email}</div>
                  )}
                </div>

                {/* Phone */}
                <div className="col">
                  <label className="form-label">Phone</label>
                  <input
                    type="number"
                    name="phone"
                    className={`form-control ${
                      errors.phone ? "is-invalid" : ""
                    }`}
                    value={formData.phone}
                    placeholder="Ex: +91 XXXXXXXXXX or 022-XXXXXXX"
                    onChange={handleChange}
                  />
                  {errors.phone && (
                    <div className="invalid-feedback">{errors.phone}</div>
                  )}
                </div>
              </div>

              {/* Address */}
              <div className="mb-3">
                <label className="form-label">Address</label>
                <input
                  type="text"
                  name="address"
                  className={`form-control ${
                    errors.address ? "is-invalid" : ""
                  }`}
                  value={formData.address}
                  placeholder="Ex: 154, Bannerghatta Rd, Krishnaraju Layout, Amalodhbavi Nagar"
                  onChange={handleChange}
                />
                {errors.address && (
                  <div className="invalid-feedback">{errors.address}</div>
                )}
              </div>

              {/* Location */}
              <div className="mb-3">
                <label className="form-label">Location</label>
                <input
                  type="text"
                  name="location"
                  className={`form-control ${
                    errors.location ? "is-invalid" : ""
                  }`}
                  value={formData.location}
                  placeholder="Ex: Bannerghatta"
                  onChange={handleChange}
                />
                {errors.location && (
                  <div className="invalid-feedback">{errors.location}</div>
                )}
              </div>

              <div className="row">
                {/* State */}
                <div className="col-md-4 mb-3">
                  <label className="form-label">Select State</label>
                  <select
                    name="stateId"
                    className={`form-select ${
                      errors.stateId ? "is-invalid" : ""
                    }`}
                    value={selectedState}
                    onChange={handleStateChange}
                  >
                    <option value="">Select a state</option>
                    {states.map((state) => (
                      <option key={state.id} value={state.id}>
                        {state.name}
                      </option>
                    ))}
                  </select>
                  {errors.stateId && (
                    <div className="invalid-feedback">{errors.stateId}</div>
                  )}
                </div>

                {/* City */}
                <div className="col-md-4 mb-3">
                  <label className="form-label">Select City</label>
                  <select
                    name="cityId"
                    className={`form-select ${
                      errors.cityId ? "is-invalid" : ""
                    }`}
                    value={selectedCity}
                    onChange={handleCityChange}
                    disabled={!selectedState}
                  >
                    <option value="">Select a city</option>
                    {cities.map((city) => (
                      <option key={city.id} value={city.id}>
                        {city.name}
                      </option>
                    ))}
                  </select>
                  {errors.cityId && (
                    <div className="invalid-feedback">{errors.cityId}</div>
                  )}
                </div>

                {/* Pincode */}
                <div className="col-md-4 mb-3">
                  <label className="form-label">Pincode</label>
                  <input
                    type="text"
                    name="pincode"
                    className={`form-control ${
                      errors.pincode ? "is-invalid" : ""
                    }`}
                    value={formData.pincode}
                    placeholder="Ex: 560055"
                    onChange={handleChange}
                  />
                  {errors.pincode && (
                    <div className="invalid-feedback">{errors.pincode}</div>
                  )}
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="btn btn-primary"
                id="formSubmitBtn"
                disabled={Object.values(errors).some((error) => error !== "")}
                // style={{ marginLeft: "40%", display: "block" }}
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HospitalRegistrationForm;
