 // useFormValidations.js
import { useState } from "react";

export const useFormValidations = () => {
  const [errors, setErrors] = useState({
    name: "",
    email: "",
    phone: "",
    location: "",
    address: "",
    pincode: "",
    stateId: "",
    cityId: "",
  });

  // Validate a specific field
  const validateField = (fieldName, fieldValue) => {
    const updatedErrors = { ...errors };

    switch (fieldName) {
      case "name":
        updatedErrors.name = fieldValue.trim() === "" ? "Name is required" : "";
        break;
      case "email":
        updatedErrors.email = !/\S+@\S+\.\S+/.test(fieldValue)
          ? "Valid email is required"
          : "";
        break;
      case "phone":
        updatedErrors.phone = !/^\+?\d{10,15}$/.test(fieldValue)
          ? "Phone number is invalid"
          : "";
        break;
      case "location":
        updatedErrors.location =
          fieldValue.trim() === "" ? "Location is required" : "";
        break;
      case "address":
        updatedErrors.address =
          fieldValue.trim() === "" ? "Address is required" : "";
        break;
      case "pincode":
        updatedErrors.pincode = !/^\d{6}$/.test(fieldValue)
          ? "Valid pincode is required"
          : "";
        break;
      case "stateId":
        updatedErrors.stateId = fieldValue === "" ? "State is required" : "";
        break;
      case "cityId":
        updatedErrors.cityId = fieldValue === "" ? "City is required" : "";
        break;
      default:
        break;
    }

    setErrors(updatedErrors);
  };

  // Validate the entire form
  const validateForm = (formData) => {
    let valid = true;
    const newErrors = { ...errors };

    Object.keys(formData).forEach((field) => {
      if (formData[field] === "" || errors[field] !== "") {
        newErrors[field] = `${field} is required or invalid`;
        valid = false;
      }
    });

    setErrors(newErrors);
    return valid;
  };

  return { errors, validateField, validateForm };
};
