import React, { useState, useEffect } from "react";
import { Form, Row, Col, Button, Container, FormControl, CloseButton } from "react-bootstrap";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";
import "./AddProduct.css";

function ProductForm() {
  const navigate = useNavigate();  // Use navigate hook directly
  const location = useLocation();
  const productFromState = location.state ? location.state.product : null;

  const [principles, setPrinciples] = useState([]);
  const [productData, setProductData] = useState(productFromState || {
    name: "",
    productCode: "",
    batchCode: "",
    dpvalue: "",
    expiryDate: "",
    mrp: "",
    quantity: "",
    principle: { name: "", id: "" },  // Ensure principle is initialized
  });

  console.log(productData);
  

  // Fetch principles for the dropdown
  useEffect(() => {
    axios.get("http://77.37.45.2:8091/api/v1/principle/fetchallprinciples")
      .then(response => setPrinciples(response.data))
      .catch(error => console.error("Error fetching principles:", error));
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProductData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handlePrincipleChange = (e) => {
    const selectedPrinciple = principles.find(
      (principle) => principle.name === e.target.value
    );
    setProductData((prevData) => ({
      ...prevData,
      principle: selectedPrinciple || {},
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const url = productFromState
      ? `http://77.37.45.2:8091/api/v1/product/updateproduct/${productFromState.id}`
      : "http://77.37.45.2:8091/api/v1/product/saveproduct";
    const method = productFromState ? "put" : "post";

    axios[method](url, productData)
      .then((response) => {
        console.log("Product saved/updated successfully:", response.data);
        // Navigate to products page after success
        navigate("/products");
      })
      .catch((error) => {
        console.error("Error submitting data:", error);
      });
  };

  return (
    <div>
      <Container className="Product-Container">
        <div className="addProductHeaderClass">
          <h3 className="addnewProductHeader">
            {productFromState ? "Edit Product" : "Add New Product"}
          </h3>
          <div id="closeModalBtnPrin">
            <CloseButton onClick={() => navigate("/products")} />  {/* Fixed navigation */}
          </div>
        </div>
        <hr />

        <Form onSubmit={handleSubmit}>
          <Row className="mb-3">
            {/* Principle Dropdown */}
            <Form.Group as={Col}>
              <Form.Label>Supplier/Principle:</Form.Label>
              <Form.Select
                name="principle"
                onChange={handlePrincipleChange}
                value={productData.principle?.name || ''}   
              >
                <option>Choose...</option>
                {principles.map(principle => (
                  <option key={principle.id} value={principle.name}>{principle.name}</option>
                ))}
              </Form.Select>
            </Form.Group>
          </Row>

          {/* Product Name */}
          <Row className="mb">
            <Form.Group as={Col}>
              <Form.Label>Product Name</Form.Label>
              <FormControl
                name="name"
                value={productData.name}
                onChange={handleInputChange}
              />
            </Form.Group>
          </Row>

          {/* Product Code */}
          <Row className="mb">
            <Form.Group as={Col}>
              <Form.Label>Product Code</Form.Label>
              <FormControl
                name="productCode"
                type="text"
                value={productData.productCode}
                onChange={handleInputChange}
              />
            </Form.Group>
          </Row>

          {/* Batch Number, DP, MRP */}
          <Row className="mb">
            <Form.Group as={Col}>
              <Form.Label>Batch Number:</Form.Label>
              <FormControl
                name="batchCode"
                type="text"
                value={productData.batchCode}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group as={Col}>
              <Form.Label>DP:</Form.Label>
              <FormControl
                name="dpvalue"
                type="number"
                value={productData.dpvalue}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group as={Col}>
              <Form.Label>MRP:</Form.Label>
              <FormControl
                name="mrp"
                type="number"
                value={productData.mrp}
                onChange={handleInputChange}
              />
            </Form.Group>
          </Row>

          {/* Expiry Date and Quantity */}
          <Row className="mb">
            <Form.Group as={Col}>
              <Form.Label>Expiry Date:</Form.Label>
              <FormControl
                name="expiryDate"
                type="date"
                value={productData.expiryDate}
                onChange={handleInputChange}
              />
            </Form.Group>

            <Form.Group as={Col}>
              <Form.Label>Quantity:</Form.Label>
              <FormControl
                name="quantity"
                type="number"
                value={productData.quantity}
                onChange={handleInputChange}
              />
            </Form.Group>
          </Row>

          {/* Submit Button */}
          <div id="ProductFormSubmitBtnDiv">
            <Button variant="primary" id="ProductFormSubmitBtn" type="submit">
              {productFromState ? "Update" : "Submit"}
            </Button>
          </div>
        </Form>
      </Container>
    </div>
  );
}

export default ProductForm;
