import React, { useEffect, useState } from "react";
import { Button, Modal, Form, Accordion, Table } from "react-bootstrap";
import axios from "axios";

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showSubCategoryModal, setShowSubCategoryModal] = useState(false);
  const [newCategory, setNewCategory] = useState("");
  const [newSubCategory, setNewSubCategory] = useState({
    name: "",
    categoryValueId: "",
  });

  const [isEditingSubCategory, setIsEditingSubCategory] = useState(false);
  const [editingSubCategoryId, setEditingSubCategoryId] = useState(null);

  // Fetch categories on component mount
  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = () => {
    axios
      .get("http://77.37.45.2:8091/api/v1/category/fetchallcategories")
      .then((response) => {
        setCategories(response.data.reverse());
      })
      .catch((error) => {
        console.error("Error fetching categories", error);
      });
  };

  const handleAddCategory = () => {
    axios
      .post("http://77.37.45.2:8091/api/v1/category/savecategory", {
        name: newCategory,
        description: "Test Category",
      })
      .then(() => {
        fetchCategories();
        setShowCategoryModal(false);
        setNewCategory("");
      })
      .catch((error) => {
        console.error("Error adding category", error);
      });
  };

  const handleAddOrEditSubCategory = () => {
    const url = isEditingSubCategory
      ? `http://77.37.45.2:8091/api/v1/subcategory/updatesubcategory/${editingSubCategoryId}`
      : "http://77.37.45.2:8091/api/v1/subcategory/savesubcategory";

    const method = isEditingSubCategory ? "put" : "post";

    axios[method](url, {
      name: newSubCategory.name,
      categoryValueId: newSubCategory.categoryValueId,
    })
      .then(() => {
        fetchCategories();
        setShowSubCategoryModal(false);
        setNewSubCategory({ name: "", categoryValueId: "" });
        setIsEditingSubCategory(false);
        setEditingSubCategoryId(null);
      })
      .catch((error) => {
        console.error(
          isEditingSubCategory
            ? "Error updating subcategory"
            : "Error adding subcategory",
          error
        );
      });
  };

  const handleEditSubCategory = (subCategory) => {
    setNewSubCategory({
      name: subCategory.name,
      categoryValueId: subCategory.categoryValueId,
    });
    setEditingSubCategoryId(subCategory.id);
    setIsEditingSubCategory(true);
    setShowSubCategoryModal(true);
  };

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10); // Default rows per page

  // Pagination Logic
  const totalItems = categories.length;
  const totalPages = Math.ceil(totalItems / rowsPerPage);

  const paginatedCategories = categories.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const displayStart = (currentPage - 1) * rowsPerPage + 1;
  const displayEnd = Math.min(currentPage * rowsPerPage, totalItems);

  return (
    <div id="tableidPrinciple" style={{ display: "block" }}>
      <div className="table-container" id="table-container-Principle">
        <div id="mainBar">
          <div id="searchBar">
            <input
              type="text"
              id="searchBarInput"
              //onChange={(e) => setSearchTerm(e.target.value)}
              //value={searchTerm}
              placeholder="Search..."
            />
          </div>

          <div id="pageHeading">
            <h1>Category</h1>
          </div>

          <div>
            <Button
              variant="primary"
              onClick={() => setShowCategoryModal(true)}
            >
              Add Category
            </Button>{" "}
            <Button
              variant="primary"
              onClick={() => setShowSubCategoryModal(true)}
            >
              Add Sub-Category
            </Button>
          </div>
        </div>

        <hr />

        <div>
          {/* Accordion for Categories and Subcategories */}
          <Accordion defaultActiveKey="0" className="mt-4">
            {paginatedCategories.map((category, index) => (
              <Accordion.Item eventKey={index.toString()} key={category.id}>
                <Accordion.Header>{category.name}</Accordion.Header>
                <Accordion.Body>
                  {category.subCategories &&
                  category.subCategories.length > 0 ? (
                    <Table striped bordered hover>
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>Sub-Categories</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {category.subCategories.map((subCategory, subIndex) => (
                          <tr key={subCategory.id}>
                            <td>{subIndex + 1}</td>
                            <td>{subCategory.name}</td>
                            <td>
                              {/* Edit icon */}
                              <i
                                className="fas fa-edit icon edit"
                                title="Edit"
                                onClick={() =>
                                  handleEditSubCategory(subCategory)
                                }
                              ></i>

                              {/* Vertical Divider */}
                              <span className="vertical-dividerPrinciple"></span>

                              {/* Delete icon */}
                              <i
                                className="fas fa-trash-alt icon delete"
                                title="Delete"
                                onClick={() => {
                                  // Add logic for deleting the subcategory
                                  console.log(
                                    "Deleting subcategory",
                                    subCategory
                                  );
                                }}
                              ></i>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  ) : (
                    <p>No sub-categories available.</p>
                  )}
                </Accordion.Body>
              </Accordion.Item>
            ))}
          </Accordion>
          {/* Modal for Adding Category */}
          <Modal
            show={showCategoryModal}
            onHide={() => setShowCategoryModal(false)}
            centered
          >
            <Modal.Header closeButton>
              <Modal.Title>Add Category</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form>
                <Form.Group controlId="categoryName">
                  <Form.Label>Category Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter category name"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                  />
                </Form.Group>
              </Form>
            </Modal.Body>
            <Modal.Footer>
              <Button
                variant="secondary"
                onClick={() => setShowCategoryModal(false)}
              >
                Close
              </Button>
              <Button variant="primary" onClick={handleAddCategory}>
                Add Category
              </Button>
            </Modal.Footer>
          </Modal>
          {/* Modal for Adding Sub-Category */}
          <Modal
            show={showSubCategoryModal}
            onHide={() => setShowSubCategoryModal(false)}
            centered
          >
            <Modal.Header closeButton>
              <Modal.Title>
                {isEditingSubCategory
                  ? "Editing Sub-Category"
                  : "Add Sub-Category"}
              </Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form>
                <Form.Group controlId="categorySelect">
                  <Form.Label>Category</Form.Label>
                  <Form.Control
                    as="select"
                    value={newSubCategory.categoryValueId}
                    onChange={(e) =>
                      setNewSubCategory({
                        ...newSubCategory,
                        categoryValueId: e.target.value,
                      })
                    }
                  >
                    <option value="">Select Category</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </Form.Control>
                </Form.Group>
                <Form.Group controlId="subCategoryName" className="mt-3">
                  <Form.Label>Sub-Category Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter sub-category name"
                    value={newSubCategory.name}
                    onChange={(e) =>
                      setNewSubCategory({
                        ...newSubCategory,
                        name: e.target.value,
                      })
                    }
                  />
                </Form.Group>
              </Form>
            </Modal.Body>
            <Modal.Footer>
              <Button
                variant="secondary"
                onClick={() => setShowSubCategoryModal(false)}
              >
                Close
              </Button>
              <Button variant="primary" onClick={handleAddOrEditSubCategory}>
                {isEditingSubCategory
                  ? "Update Sub-Category"
                  : "Add Sub-Category"}
              </Button>
            </Modal.Footer>
          </Modal>
        </div>

        {/* Pagination Controls */}
        <div className="pagination-controls">
          <div className="rows-per-page">
            Rows per page:
            <select
              style={{ border: "0px" }}
              value={rowsPerPage}
              onChange={(e) => {
                setRowsPerPage(Number(e.target.value));
                setCurrentPage(1); // Reset to first page on rows-per-page change
              }}
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
              <option value={totalItems}>All</option>
            </select>
          </div>

          <div className="pagination-info">
            {displayStart}-{displayEnd} of {totalItems}
          </div>

          <button
            onClick={() => setCurrentPage(currentPage - 1)}
            disabled={currentPage === 1}
          >
            {"<"}
          </button>

          <button
            onClick={() => setCurrentPage(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            {">"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Categories;
