import Dashboard from "./MainComponents/DashBoard/Dashboard";
import 'bootstrap/dist/css/bootstrap.min.css';




function App() {
  return (
    <div>
      <Dashboard />
    </div>
  );
}

export default App;

